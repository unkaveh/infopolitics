﻿Imports Microsoft.VisualBasic

Namespace BillSearchModel
    Public Class BillSearch
        Public Property title As String
        Public Property created_at As String
        Public Property updated_at As String
        Public Property id As String
        Public Property chamber As String
        Public Property state As String
        Public Property session As String
        Public Property type As String()
        Public Property subjects As String()
        Public Property bill_id As String
    End Class
End Namespace
