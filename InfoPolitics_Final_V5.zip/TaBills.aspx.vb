﻿
Partial Class TaBills
    Inherits System.Web.UI.Page




End Class
