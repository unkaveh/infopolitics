﻿Imports Microsoft.VisualBasic

Public Class goFedStateLegislatorsModel
    
End Class
